Contains assets for the Github home page.
